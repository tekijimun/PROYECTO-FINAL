import bcrypt

def hash_password(password: str) -> str:

    hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt())
    return hashed.decode()  

def verify_password(password: str, hashed_str: str) -> bool:

    try:
        return bcrypt.checkpw(password.encode(), hashed_str.encode())
    except Exception as e:
        print(f"Error verificando contraseña: {e}")
        return False