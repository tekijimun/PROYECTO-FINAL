import sqlite3

def inicializar_base_datos():
    conn = sqlite3.connect("tienda.db")
    cursor = conn.cursor()

    # Crear tabla usuarios
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    """)

    # Crear tabla videojuegos
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS videojuegos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            descripcion TEXT,
            precio REAL NOT NULL,
            imagen TEXT,
            stock INTEGER DEFAULT 0
        )
    """)


    # Crear tabla carrito
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS carrito (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            videojuego_id INTEGER NOT NULL,
            cantidad INTEGER DEFAULT 1,
            FOREIGN KEY (user_id) REFERENCES usuarios(id),
            FOREIGN KEY (videojuego_id) REFERENCES videojuegos(id)
        )
    """)

    conn.commit()
    conn.close()
