import tkinter as tk
from gui.login_user import login_user
from admin.login_admin import login_admin
from utilidades.db_init import  inicializar_base_datos
inicializar_base_datos()


def abrir_usuario(root):
    root.withdraw()  
    login_user(root)

def abrir_admin(root):
    root.withdraw()
    login_admin(root)

def main():
    root = tk.Tk()
    root.title("Lobotienda de Videojuegos")
    root.geometry("300x200")

    tk.Label(root, text="Bienvenido a la Tienda", font=("Arial", 14, "bold")).pack(pady=20)

    tk.Button(root, text="Ingresar como Usuario", width=25, command=lambda: abrir_usuario(root)).pack(pady=5)
    tk.Button(root, text="Ingresar como Administrador", width=25, command=lambda: abrir_admin(root)).pack(pady=5)

    root.mainloop()

if __name__ == "__main__":
    main()
