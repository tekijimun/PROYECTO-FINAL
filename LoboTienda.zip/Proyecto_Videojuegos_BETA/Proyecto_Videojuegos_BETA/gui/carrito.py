import tkinter as tk
from tkinter import messagebox
import sqlite3

def mostrar_carrito(user_id):
    ventana = tk.Toplevel()
    ventana.title("Carrito de Compras")
    ventana.geometry("500x400")

    # Contenedor para tabla y total, así podemos limpiar fácilmente
    contenedor = tk.Frame(ventana)
    contenedor.pack(fill="both", expand=True, padx=10, pady=10)

    def refrescar_carrito():
        # Limpiar contenido previo
        for widget in contenedor.winfo_children():
            widget.destroy()

        conn = sqlite3.connect("tienda.db")
        cursor = conn.cursor()

        cursor.execute('''
            SELECT c.id, v.nombre, c.cantidad, v.precio
            FROM carrito c
            JOIN videojuegos v ON c.videojuego_id = v.id
            WHERE c.user_id = ?
        ''', (user_id,))
        items = cursor.fetchall()
        conn.close()

        if not items:
            tk.Label(contenedor, text="El carrito está vacío.", font=("Arial", 14)).pack(pady=20)
            return

        tabla = tk.Frame(contenedor)
        tabla.pack()

        total = 0
        for i, (id_carrito, nombre, cantidad, precio) in enumerate(items):
            tk.Label(tabla, text=nombre).grid(row=i, column=0)
            tk.Label(tabla, text=f"${precio:.2f}").grid(row=i, column=1)
            tk.Label(tabla, text=f"x{cantidad}").grid(row=i, column=2)
            
            total += cantidad * precio

            tk.Button(tabla, text="+", command=lambda c=id_carrito: actualizar_cantidad(c, 1)).grid(row=i, column=3)
            tk.Button(tabla, text="-", command=lambda c=id_carrito, cant=cantidad: disminuir_cantidad(c, cant)).grid(row=i, column=4)
            tk.Button(tabla, text="Quitar", command=lambda c=id_carrito: confirmar_eliminar(c)).grid(row=i, column=5)

        tk.Label(contenedor, text=f"Total: ${total:.2f}", font=("Arial", 14)).pack(pady=10)

        btn_pagar = tk.Button(contenedor, text="Pagar con PayPal (futuro)", state="disabled")
        btn_pagar.pack()
        btn_pagar.bind("<Enter>", lambda e: messagebox.showinfo("Info", "Funcionalidad en desarrollo."))

    def actualizar_cantidad(id_carrito, delta):
        conn = sqlite3.connect("tienda.db")
        cursor = conn.cursor()

        cursor.execute("SELECT cantidad FROM carrito WHERE id=?", (id_carrito,))
        resultado = cursor.fetchone()
        if not resultado:
            conn.close()
            messagebox.showerror("Error", "Item no encontrado en el carrito.")
            return

        cantidad = resultado[0]
        nueva_cantidad = cantidad + delta

        if nueva_cantidad <= 0:
            if messagebox.askyesno("Confirmar", "¿Eliminar este juego del carrito?"):
                cursor.execute("DELETE FROM carrito WHERE id=?", (id_carrito,))
        else:
            cursor.execute("UPDATE carrito SET cantidad=? WHERE id=?", (nueva_cantidad, id_carrito))

        conn.commit()
        conn.close()
        refrescar_carrito()

    def disminuir_cantidad(id_carrito, cantidad_actual):
        if cantidad_actual <= 1:
            if messagebox.askyesno("Confirmar", "¿Eliminar este juego del carrito?"):
                eliminar_item(id_carrito)
        else:
            actualizar_cantidad(id_carrito, -1)

    def eliminar_item(id_carrito):
        conn = sqlite3.connect("tienda.db")
        cursor = conn.cursor()
        cursor.execute("DELETE FROM carrito WHERE id=?", (id_carrito,))
        conn.commit()
        conn.close()
        refrescar_carrito()

    def confirmar_eliminar(id_carrito):
        if messagebox.askyesno("Confirmar", "¿Eliminar este juego del carrito?"):
            eliminar_item(id_carrito)

    refrescar_carrito()
