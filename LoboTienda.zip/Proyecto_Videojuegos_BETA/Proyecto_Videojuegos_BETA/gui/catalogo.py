import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image, ImageTk
import sqlite3
import os

def mostrar_catalogo(contenedor, user_id, filtro=""):
    for widget in contenedor.winfo_children():
        widget.destroy()

    def verificar_tabla_carrito():
        conn = sqlite3.connect("tienda.db")
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS carrito (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                videojuego_id INTEGER NOT NULL,
                cantidad INTEGER NOT NULL,
                FOREIGN KEY(user_id) REFERENCES usuarios(id),
                FOREIGN KEY(videojuego_id) REFERENCES videojuegos(id)
            )
        """)
        conn.commit()
        conn.close()

    verificar_tabla_carrito()

    conn = sqlite3.connect("tienda.db")
    cursor = conn.cursor()

    if filtro:
        query = f"%{filtro}%"
        cursor.execute("SELECT id, nombre, descripcion, precio, imagen FROM videojuegos WHERE nombre LIKE ?", (query,))
    else:
        cursor.execute("SELECT id, nombre, descripcion, precio, imagen FROM videojuegos")

    juegos = cursor.fetchall()
    conn.close()

    if not juegos:
        tk.Label(contenedor, text="No se encontraron juegos.", font=("Arial", 14)).pack(pady=20)
        return

    def agregar_al_carrito(videojuego_id):
        try:
            conn = sqlite3.connect("tienda.db")
            cursor = conn.cursor()
            cursor.execute("SELECT cantidad FROM carrito WHERE user_id=? AND videojuego_id=?", (user_id, videojuego_id))
            resultado = cursor.fetchone()
            if resultado:
                cantidad = resultado[0] + 1
                cursor.execute("UPDATE carrito SET cantidad=? WHERE user_id=? AND videojuego_id=?", (cantidad, user_id, videojuego_id))
            else:
                cursor.execute("INSERT INTO carrito (user_id, videojuego_id, cantidad) VALUES (?, ?, 1)", (user_id, videojuego_id))
            conn.commit()
            conn.close()
            messagebox.showinfo("Carrito", f"Juego con ID {videojuego_id} agregado al carrito.")
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo agregar al carrito:\n{e}")

    for juego in juegos:
        videojuego_id, nombre, descripcion, precio, imagen_nombre = juego

        frame_juego = ttk.Frame(contenedor, relief="raised", borderwidth=2, padding=10)
        frame_juego.pack(fill="x", padx=10, pady=5)

        ruta_imagen = os.path.join("assets", "imagenes", imagen_nombre) if imagen_nombre else ""

        if ruta_imagen and os.path.exists(ruta_imagen):
            try:
                img = Image.open(ruta_imagen).resize((80, 80), Image.Resampling.LANCZOS)
                foto = ImageTk.PhotoImage(img)
                label_img = ttk.Label(frame_juego, image=foto)
                label_img.image = foto  # mantener referencia
                label_img.pack(side="left", padx=10)
            except Exception as e:
                print(f"[ERROR] No se pudo cargar imagen {ruta_imagen}: {e}")
                ttk.Label(frame_juego, text="📦", font=("Arial", 32)).pack(side="left", padx=10)
        else:
            print(f"[WARNING] Imagen no encontrada: {ruta_imagen}")
            ttk.Label(frame_juego, text="📦", font=("Arial", 32)).pack(side="left", padx=10)

        info_frame = ttk.Frame(frame_juego)
        info_frame.pack(side="left", fill="both", expand=True)

        ttk.Label(info_frame, text=f"ID: {videojuego_id}", font=("Arial", 9, "italic")).pack(anchor="w")
        ttk.Label(info_frame, text=nombre, font=("Arial", 12, "bold")).pack(anchor="w")
        ttk.Label(info_frame, text=descripcion, wraplength=600).pack(anchor="w")
        ttk.Label(info_frame, text=f"Precio: ${precio:.2f}", foreground="green", font=("Arial", 11, "bold")).pack(anchor="w")

        btn_agregar = ttk.Button(frame_juego, text="Agregar al carrito", command=lambda id=videojuego_id: agregar_al_carrito(id))
        btn_agregar.pack(side="right", padx=10, pady=10)
