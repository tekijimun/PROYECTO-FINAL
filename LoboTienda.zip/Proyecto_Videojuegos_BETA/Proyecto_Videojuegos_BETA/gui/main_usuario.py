import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from PIL import Image, ImageTk
import sqlite3
from gui.catalogo import mostrar_catalogo
from gui.carrito import mostrar_carrito

def ventana_usuario(user_id):
    root = tk.Tk()
    root.title("Lobotienda de Videojuegos")
    root.geometry("1000x700")
    root.resizable(False, False)

    navbar = tk.Frame(root, bg="#222", height=60)
    navbar.pack(side="top", fill="x")

    try:
        img = Image.open("assets/imagenes/user.png").resize((40, 40))
        foto = ImageTk.PhotoImage(img)
        tk.Label(navbar, image=foto, bg="#222").pack(side="left", padx=10)
    except Exception as e:
        tk.Label(navbar, text="👤", bg="#222", fg="white", font=("Arial", 18)).pack(side="left", padx=10)

    # Obtener nombre de usuario
    try:
        conn = sqlite3.connect("tienda.db")
        cursor = conn.cursor()
        cursor.execute("SELECT username FROM usuarios WHERE id=?", (user_id,))
        resultado = cursor.fetchone()
        conn.close()
        nombre_usuario = resultado[0] if resultado else "Usuario"
    except Exception as e:
        messagebox.showerror("Error", f"No se pudo cargar el nombre de usuario:\n{e}")
        nombre_usuario = "Usuario"

    tk.Label(navbar, text=f"Bienvenido, {nombre_usuario}", fg="white", bg="#222", font=("Arial", 12)).pack(side="left")

    buscador = tk.Entry(navbar)
    buscador.pack(side="right", padx=10)

    def buscar():
        query = buscador.get().strip()
        mostrar_catalogo(contenedor, user_id, query)

    tk.Button(navbar, text="Buscar", command=buscar).pack(side="right", padx=5)
    tk.Button(navbar, text="🛒", font=("Arial", 18), command=lambda: mostrar_carrito(user_id)).pack(side="right", padx=10)

    # --- Botón para abrir ventana de agregar juego ---
    def agregar_juego_ui():
        ventana = tk.Toplevel(root)
        ventana.title("Agregar Nuevo Juego")
        ventana.geometry("400x400")

        tk.Label(ventana, text="Nombre:").pack()
        entry_nombre = tk.Entry(ventana, width=40)
        entry_nombre.pack()

        tk.Label(ventana, text="Descripción:").pack()
        entry_descripcion = tk.Text(ventana, height=5, width=40)
        entry_descripcion.pack()

        tk.Label(ventana, text="Precio:").pack()
        entry_precio = tk.Entry(ventana, width=20)
        entry_precio.pack()

        tk.Label(ventana, text="Imagen:").pack()
        entry_imagen = tk.Entry(ventana, width=40)
        entry_imagen.pack(side="left", padx=5)

        def seleccionar_imagen():
            ruta = filedialog.askopenfilename(
                title="Seleccionar imagen",
                filetypes=[("Archivos de imagen", "*.png *.jpg *.jpeg *.gif")]
            )
            if ruta:
                entry_imagen.delete(0, tk.END)
                entry_imagen.insert(0, ruta)

        tk.Button(ventana, text="Examinar", command=seleccionar_imagen).pack(side="left")

        def guardar_juego():
            nombre = entry_nombre.get().strip()
            descripcion = entry_descripcion.get("1.0", tk.END).strip()
            precio = entry_precio.get().strip()
            imagen = entry_imagen.get().strip()

            if not nombre or not descripcion or not precio:
                messagebox.showerror("Error", "Completa todos los campos obligatorios.")
                return

            try:
                precio_val = float(precio)
            except ValueError:
                messagebox.showerror("Error", "Precio inválido. Usa un número.")
                return

            # Validar imagen (opcional)
            if imagen:
                try:
                    img = Image.open(imagen)
                    img.close()
                except Exception:
                    messagebox.showerror("Error", "Ruta de imagen inválida o archivo no soportado.")
                    return

            try:
                conn = sqlite3.connect("tienda.db")
                cursor = conn.cursor()
                cursor.execute(
                    "INSERT INTO videojuegos (nombre, descripcion, precio, imagen) VALUES (?, ?, ?, ?)",
                    (nombre, descripcion, precio_val, imagen)
                )
                conn.commit()
                conn.close()
                messagebox.showinfo("Éxito", f"Juego '{nombre}' agregado correctamente.")
                ventana.destroy()
                # REFRESCAR CATÁLOGO tras agregar juego
                mostrar_catalogo(contenedor, user_id)
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo guardar el juego:\n{e}")

        tk.Button(ventana, text="Guardar Juego", command=guardar_juego).pack(pady=20)

    tk.Button(navbar, text="+ Agregar Juego", bg="#4CAF50", fg="white", command=agregar_juego_ui).pack(side="left", padx=10)

    contenedor = tk.Frame(root)
    contenedor.pack(fill="both", expand=True)

    mostrar_catalogo(contenedor, user_id)

    root.mainloop()
