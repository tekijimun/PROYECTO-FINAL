import tkinter as tk
from tkinter import messagebox
import sqlite3
from utilidades.autenticacion import verify_password, hash_password
from gui.main_usuario import ventana_usuario

def login_user(root):
    login_win = tk.Toplevel(root)
    login_win.title("Login Usuario")
    login_win.geometry("300x250")
    login_win.resizable(False, False)

    tk.Label(login_win, text="Usuario:").pack(pady=5)
    entry_user = tk.Entry(login_win)
    entry_user.pack()

    tk.Label(login_win, text="Contraseña:").pack(pady=5)
    entry_pass = tk.Entry(login_win, show="*")
    entry_pass.pack()

    def verificar():
        usuario = entry_user.get().strip()
        contrasena = entry_pass.get().strip()

        if not usuario or not contrasena:
            messagebox.showwarning("Campos vacíos", "Llena todos los campos.")
            return

        try:
            conn = sqlite3.connect("tienda.db")
            cursor = conn.cursor()
            cursor.execute("SELECT id, password FROM usuarios WHERE username = ?", (usuario,))
            resultado = cursor.fetchone()
            conn.close()

            if resultado and verify_password(contrasena, resultado[1]):
                user_id = resultado[0]
                login_win.destroy()
                ventana_usuario(user_id)
            else:
                messagebox.showerror("Error", "Credenciales inválidas")
        except Exception as e:
            messagebox.showerror("Error", f"Ocurrió un problema al verificar: {e}")

    def abrir_ventana_registro():
        ventana = tk.Toplevel(login_win)
        ventana.title("Registro")
        ventana.geometry("300x200")
        ventana.resizable(False, False)

        tk.Label(ventana, text="Nuevo Usuario").pack()
        entry_new_user = tk.Entry(ventana)
        entry_new_user.pack()

        tk.Label(ventana, text="Nueva Contraseña").pack()
        entry_new_pass = tk.Entry(ventana, show="*")
        entry_new_pass.pack()

        def registrar():
            user = entry_new_user.get().strip()
            pwd = entry_new_pass.get().strip()

            if not user or not pwd:
                messagebox.showerror("Error", "Llena todos los campos.")
                return

            hashed = hash_password(pwd)

            try:
                conn = sqlite3.connect("tienda.db")
                cursor = conn.cursor()
                cursor.execute("INSERT INTO usuarios (username, password) VALUES (?, ?)", (user, hashed))
                conn.commit()
                conn.close()
                messagebox.showinfo("Éxito", "Usuario registrado.")
                ventana.destroy()
            except sqlite3.IntegrityError:
                messagebox.showerror("Error", "El usuario ya existe.")
            except Exception as e:
                messagebox.showerror("Error", f"Error al registrar: {e}")

        tk.Button(ventana, text="Registrar", command=registrar).pack(pady=10)


    tk.Button(login_win, text="Ingresar", command=verificar).pack(pady=10)
    tk.Button(login_win, text="Registrarse", command=abrir_ventana_registro).pack(pady=5)


    login_win.protocol("WM_DELETE_WINDOW", lambda: (login_win.destroy(), root.deiconify()))
