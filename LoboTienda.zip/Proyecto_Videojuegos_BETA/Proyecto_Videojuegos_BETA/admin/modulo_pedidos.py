import tkinter as tk
import os
from tkinter import messagebox
import webbrowser

def ver_pedidos():
    ventana = tk.Toplevel()
    ventana.title("Pedidos Realizados")
    ventana.geometry("500x400")

    carpeta = "pedidos"
    if not os.path.exists(carpeta):
        os.makedirs(carpeta)

    archivos = os.listdir(carpeta)
    pdfs = [a for a in archivos if a.lower().endswith(".pdf")]

    if not pdfs:
        tk.Label(ventana, text="No hay pedidos disponibles actualmente.", font=("Arial", 12)).pack(pady=20)
        return

    tk.Label(ventana, text="Pedidos disponibles:", font=("Arial", 14, "bold")).pack(pady=10)

    for archivo in pdfs:
        ruta = os.path.join(carpeta, archivo)
        def abrir_pdf(ruta_pdf=ruta):
            try:
                webbrowser.open(ruta_pdf)
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo abrir el archivo:\n{e}")
        tk.Button(ventana, text=archivo, command=abrir_pdf).pack(pady=2)
