
import tkinter as tk
import sqlite3
from fpdf import FPDF
from tkinter import messagebox

def generar_reportes():
    ventana = tk.Toplevel()
    ventana.title("Reportes de Ventas")
    ventana.geometry("500x400")

    conn = sqlite3.connect("tienda.db")
    cursor = conn.cursor()
    cursor.execute("SELECT nombre, SUM(cantidad), SUM(cantidad * precio) FROM ventas GROUP BY nombre")
    datos = cursor.fetchall()
    conn.close()

    for nombre, cantidad, total in datos:
        tk.Label(ventana, text=f"{nombre}: {cantidad} vendidos - Total: ${total:.2f}").pack()

    def exportar_pdf():
        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Arial", size=12)
        pdf.cell(200, 10, txt="Reporte de Ventas", ln=True, align="C")

        for nombre, cantidad, total in datos:
            pdf.cell(200, 10, txt=f"{nombre}: {cantidad} vendidos - Total: ${total:.2f}", ln=True)

        pdf.output("reporte_ventas.pdf")
        messagebox.showinfo("Exportado", "Reporte generado exitosamente")

    tk.Button(ventana, text="Exportar a PDF", command=exportar_pdf).pack(pady=10)
