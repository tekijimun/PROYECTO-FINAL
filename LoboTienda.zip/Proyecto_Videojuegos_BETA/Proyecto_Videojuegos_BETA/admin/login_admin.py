import tkinter as tk
from tkinter import messagebox

def login_admin(root):
    login_win = tk.Toplevel()
    login_win.title("Login Administrador")
    login_win.geometry("300x200")

    tk.Label(login_win, text="Usuario:").pack(pady=5)
    entry_user = tk.Entry(login_win)
    entry_user.pack()

    tk.Label(login_win, text="Contraseña:").pack(pady=5)
    entry_pass = tk.Entry(login_win, show="*")
    entry_pass.pack()

    def verificar():
        usuario = entry_user.get()
        contrasena = entry_pass.get()

        if usuario == "admin" and contrasena == "admin123":
            login_win.destroy()
            from admin.dashboard_admin import dashboard
            dashboard()
        else:
            messagebox.showerror("Error", "Credenciales inválidas")

    tk.Button(login_win, text="Ingresar", command=verificar).pack(pady=10)

    login_win.protocol("WM_DELETE_WINDOW", lambda: (login_win.destroy(), root.deiconify()))
