import tkinter as tk
import sqlite3

def consultar_inventario():
    ventana = tk.Toplevel()
    ventana.title("Inventario")
    ventana.geometry("500x400")

    conn = sqlite3.connect("tienda.db")
    cursor = conn.cursor()
    cursor.execute("SELECT id, nombre, precio FROM videojuegos")
    datos = cursor.fetchall()
    conn.close()

    for id_, nombre, precio in datos:
        tk.Label(ventana, text=f"ID: {id_} | {nombre} - Precio: ${precio:.2f}").pack()
