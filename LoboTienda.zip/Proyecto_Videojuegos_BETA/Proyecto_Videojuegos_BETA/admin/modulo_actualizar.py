import tkinter as tk
from tkinter import messagebox
import sqlite3

def actualizar_videojuego():
    ventana = tk.Toplevel()
    ventana.title("Actualizar/Eliminar Videojuego")
    ventana.geometry("400x400")

    tk.Label(ventana, text="ID del Videojuego:").pack()
    entry_id = tk.Entry(ventana)
    entry_id.pack()

    tk.Label(ventana, text="Nuevo Nombre:").pack()
    entry_nombre = tk.Entry(ventana)
    entry_nombre.pack()

    tk.Label(ventana, text="Nueva Descripción:").pack()
    entry_descripcion = tk.Entry(ventana)
    entry_descripcion.pack()

    tk.Label(ventana, text="Nuevo Precio:").pack()
    entry_precio = tk.Entry(ventana)
    entry_precio.pack()

    def actualizar():
        id_juego = entry_id.get().strip()
        nombre = entry_nombre.get().strip()
        descripcion = entry_descripcion.get().strip()
        precio = entry_precio.get().strip()

        if not id_juego.isdigit():
            messagebox.showerror("Error", "El ID debe ser un número.")
            return
        if not nombre:
            messagebox.showerror("Error", "El nombre no puede estar vacío.")
            return
        try:
            precio = float(precio)
        except ValueError:
            messagebox.showerror("Error", "El precio debe ser un número.")
            return

        try:
            conn = sqlite3.connect("tienda.db")
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE videojuegos SET nombre=?, descripcion=?, precio=? WHERE id=?",
                (nombre, descripcion, precio, int(id_juego))
            )
            if cursor.rowcount == 0:
                messagebox.showwarning("Advertencia", "No se encontró ningún videojuego con ese ID.")
            else:
                messagebox.showinfo("Éxito", "Videojuego actualizado correctamente.")
            conn.commit()
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo actualizar:\n{e}")
        finally:
            conn.close()

    def eliminar():
        id_juego = entry_id.get().strip()
        if not id_juego.isdigit():
            messagebox.showerror("Error", "El ID debe ser un número.")
            return

        if not messagebox.askyesno("Confirmar", "¿Estás seguro de eliminar este videojuego?"):
            return

        try:
            conn = sqlite3.connect("tienda.db")
            cursor = conn.cursor()
            cursor.execute("DELETE FROM videojuegos WHERE id=?", (int(id_juego),))
            if cursor.rowcount == 0:
                messagebox.showwarning("Advertencia", "No se encontró ningún videojuego con ese ID.")
            else:
                messagebox.showinfo("Éxito", "Videojuego eliminado.")
            conn.commit()
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo eliminar:\n{e}")
        finally:
            conn.close()

    tk.Button(ventana, text="Actualizar", command=actualizar).pack(pady=5)
    tk.Button(ventana, text="Eliminar", command=eliminar).pack(pady=5)
