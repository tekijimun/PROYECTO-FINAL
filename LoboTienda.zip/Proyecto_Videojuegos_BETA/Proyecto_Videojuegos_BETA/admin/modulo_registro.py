import tkinter as tk
from tkinter import filedialog, messagebox
import sqlite3
import shutil
import os

def registrar_videojuego():
    ventana = tk.Toplevel()
    ventana.title("Registrar Videojuego")
    ventana.geometry("400x500")

    tk.Label(ventana, text="Nombre del Juego:").pack()
    nombre = tk.Entry(ventana)
    nombre.pack()

    tk.Label(ventana, text="Precio:").pack()
    precio = tk.Entry(ventana)
    precio.pack()

    tk.Label(ventana, text="Descripción:").pack()
    descripcion = tk.Text(ventana, height=5, width=40)
    descripcion.pack()

    imagen_path = tk.StringVar()

    def seleccionar_imagen():
        path = filedialog.askopenfilename(filetypes=[("Imágenes", "*.png;*.jpg;*.jpeg")])
        if path:
            imagen_path.set(path)

    tk.Button(ventana, text="Seleccionar Imagen", command=seleccionar_imagen).pack(pady=5)
    tk.Label(ventana, textvariable=imagen_path).pack()

    def guardar():
        n = nombre.get()
        try:
            p = float(precio.get())
        except ValueError:
            messagebox.showerror("Error", "Precio inválido.")
            return

        d = descripcion.get("1.0", tk.END).strip()
        img = imagen_path.get()

        if not n or not d or not img:
            messagebox.showerror("Error", "Todos los campos deben estar completos.")
            return

        if not os.path.exists("assets/imagenes"):
            os.makedirs("assets/imagenes")

        dest_img = f"assets/imagenes/{os.path.basename(img)}"
        shutil.copy(img, dest_img)

        conn = sqlite3.connect("tienda.db")
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO videojuegos (nombre, precio, imagen, descripcion) VALUES (?, ?, ?, ?)",
            (n, p, dest_img, d)
        )
        conn.commit()
        conn.close()
        messagebox.showinfo("Éxito", "Videojuego registrado.")
        ventana.destroy()

    tk.Button(ventana, text="Guardar", command=guardar).pack(pady=20)
