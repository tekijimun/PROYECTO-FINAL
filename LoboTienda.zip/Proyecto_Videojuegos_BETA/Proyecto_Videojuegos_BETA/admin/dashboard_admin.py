import tkinter as tk
from tkinter import messagebox

def dashboard():
    root = tk.Tk()
    root.title("Panel de Administrador")
    root.geometry("400x400")
    root.resizable(False, False)

    tk.Label(root, text="Panel de Control", font=("Arial", 16, "bold")).pack(pady=20)

    try:
        from admin.modulo_registro import registrar_videojuego
        from admin.modulo_actualizar import actualizar_videojuego
        from admin.modulo_inventario import consultar_inventario
        from admin.modulo_reportes import generar_reportes
        from admin.modulo_pedidos import ver_pedidos
    except ImportError as e:
        messagebox.showerror("Error de Importación", f"No se pudieron importar los módulos:\n{e}")
        return

    botones = [
        ("Registrar Videojuego", registrar_videojuego),
        ("Actualizar/Eliminar Videojuego", actualizar_videojuego),
        ("Consultar Inventario", consultar_inventario),
        ("Reportes de Ventas", generar_reportes),
        ("Pedidos (PDF)", ver_pedidos)
    ]

    for texto, comando in botones:
        tk.Button(root, text=texto, width=25, height=2, command=comando).pack(pady=5)

    root.mainloop()
